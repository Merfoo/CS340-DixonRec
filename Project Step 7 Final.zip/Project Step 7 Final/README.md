CS 340 Dixon Recreational Center
